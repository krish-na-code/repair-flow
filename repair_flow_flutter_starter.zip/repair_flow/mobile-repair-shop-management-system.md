# Mobile Repair Shop Management System (RepairFlow)
### Complete Technical Blueprint — PRD · Database · Architecture · API · Deployment

**Version:** 1.0
**Stack:** Flutter (Android/iOS/Web/Windows/macOS/Linux) · Supabase (PostgreSQL, Auth, Storage, Realtime, Edge Functions)
**Architecture:** Clean Architecture + Riverpod + Repository Pattern

---

## How to use this document

This is a founding technical package, not shippable code. A system of this scope (customer CRM, device intake, QR tracking, invoicing, inventory, payments, multi-role dashboards, 6 platform targets) is a 4–8 month build for a small team. What follows gives you everything needed to start sprint 1 immediately:

- Section 1: PRD (scope, personas, MVP vs. Phase 2)
- Section 2: Full PostgreSQL schema with RLS policies (paste-and-run)
- Section 3: ER relationships
- Section 4: Flutter clean-architecture folder structure
- Section 5: API / Edge Function contracts
- Section 6: Screen flow & wireframe specs (as structured layouts, not bitmaps)
- Section 7: State/notification workflow logic
- Section 8: Design system tokens
- Section 9: Deployment guide
- Section 10: Suggested build roadmap

If you want, I can follow this up with: (a) an interactive clickable dashboard mockup, (b) the actual Flutter starter repo with auth + one full module wired to Supabase, or (c) the invoice/receipt PDF template. Say which and I'll build it next — trying to generate all of them in one pass would produce shallow, unusable code for each.

---

## 1. Product Requirements Document (PRD)

### 1.1 Problem Statement
Independent and chain mobile repair shops track jobs on paper or WhatsApp, causing lost devices, disputed handovers, no proof of condition-at-intake, delayed customer updates, and no visibility into technician load or part stock. RepairFlow digitizes intake-to-delivery with a verifiable audit trail (photos, signature, QR) and gives customers self-serve status tracking.

### 1.2 Target Users / Personas

| Persona | Role | Core Need |
|---|---|---|
| Shop Owner | Admin | Revenue visibility, multi-branch control, reports |
| Manager | Manager | Daily ops, technician assignment, inventory |
| Front Desk | Receptionist | Fast intake, receipt printing, payment collection |
| Technician | Technician | Job queue, update status, log parts used |
| End Customer | Customer (portal, no login required for tracking) | "Where's my phone?" via QR/link |

### 1.3 MVP Scope (Phase 1 — ship first)
1. Auth + role-based access (Admin, Manager, Technician, Receptionist)
2. Customer management (CRUD + history)
3. Device intake with photos, condition checklist, signature, auto Job ID
4. Repair status workflow (9 states) + timeline
5. QR-code public tracking page (no login)
6. Invoice generation (GST-ready) + PDF + share (WhatsApp/Email link)
7. Payment logging (cash/UPI/card) with advance/balance tracking
8. Technician job queue + status updates
9. Basic notifications (WhatsApp via API + SMS + email) on status change
10. Core reports: daily/monthly repairs, revenue, pending jobs

### 1.4 Phase 2 (post-MVP)
- Inventory management with stock alerts, supplier PO
- Warranty tracking + claims
- Customer login portal (payment history, warranty lookup)
- Technician performance dashboard, KPIs, leaderboards
- Excel export, P&L reports
- Multi-branch / franchise support
- Offline-first sync for flaky-connectivity shops

### 1.5 Non-functional requirements
- Realtime sync across devices (Supabase Realtime channels)
- Offline queue for intake forms in low-connectivity areas (local Drift DB → sync)
- Encrypted-at-rest for device lock PIN/password (pgcrypto, never returned in plain list views)
- Audit log for every status change, payment, and record edit
- Automatic nightly backups (Supabase PITR / pg_dump to cold storage)
- 99.5% uptime target, sub-300ms P95 for read queries at 10k jobs/shop

### 1.6 Success Metrics
- Avg. intake time < 4 minutes
- % customers who scan QR at least once > 60%
- Reduction in "where's my device" support calls
- Invoice generation time < 15 seconds after job marked Ready

---

## 2. Database Schema (PostgreSQL / Supabase)

Design notes:
- Multi-tenant via `shop_id` on every business table + RLS keyed to `auth.uid()` membership in `shop_staff`.
- Soft deletes via `deleted_at` (never hard-delete financial/audit records).
- `pgcrypto` used to encrypt device lock codes; app decrypts client-side only for staff with permission.
- All money columns are `numeric(12,2)`, currency assumed shop-level default (`shops.currency`).

```sql
-- ============================================================
-- EXTENSIONS
-- ============================================================
create extension if not exists "uuid-ossp";
create extension if not exists pgcrypto;

-- ============================================================
-- ENUMS
-- ============================================================
create type user_role as enum ('admin','manager','technician','receptionist');
create type repair_stage as enum (
  'received','diagnosing','waiting_approval','waiting_spare_parts',
  'in_progress','testing','ready','delivered','cancelled'
);
create type payment_method as enum ('cash','upi','credit_card','debit_card','net_banking');
create type payment_status as enum ('pending','partial','paid','refunded');
create type lock_type as enum ('none','pin','pattern','password','face_id','fingerprint');
create type notification_channel as enum ('push','whatsapp','sms','email');

-- ============================================================
-- SHOPS (multi-tenant root)
-- ============================================================
create table shops (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  logo_url text,
  gstin text,
  address text, city text, state text, pincode text,
  phone text, email text,
  currency text default 'INR',
  invoice_prefix text default 'INV',
  job_prefix text default 'JOB',
  terms_and_conditions text,
  created_at timestamptz default now(),
  deleted_at timestamptz
);

create table shop_staff (
  id uuid primary key default uuid_generate_v4(),
  shop_id uuid references shops(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  role user_role not null,
  full_name text not null,
  mobile text,
  skills text[],
  is_active boolean default true,
  created_at timestamptz default now(),
  unique(shop_id, user_id)
);

-- ============================================================
-- CUSTOMERS
-- ============================================================
create table customers (
  id uuid primary key default uuid_generate_v4(),
  shop_id uuid references shops(id) on delete cascade,
  full_name text not null,
  mobile text not null,
  alt_mobile text,
  email text,
  address text, city text, state text, pincode text,
  notes text,
  auth_user_id uuid references auth.users(id), -- set if customer registers on portal
  created_at timestamptz default now(),
  deleted_at timestamptz
);
create index idx_customers_shop_mobile on customers(shop_id, mobile);

-- ============================================================
-- REPAIR JOBS (device intake)
-- ============================================================
create table repair_jobs (
  id uuid primary key default uuid_generate_v4(),
  shop_id uuid references shops(id) on delete cascade,
  job_number text not null,               -- e.g. JOB-2026-000123
  customer_id uuid references customers(id),
  assigned_technician_id uuid references shop_staff(id),

  -- device details
  brand text, model text,
  imei text, serial_number text,
  color text, storage_variant text,
  lock_type lock_type default 'none',
  lock_secret_encrypted bytea,            -- pgcrypto encrypted PIN/password
  sim_available boolean default false,
  memory_card_available boolean default false,
  accessories jsonb default '{}'::jsonb,  -- {charger:true, earphones:false, box:true, back_cover:true, tempered_glass:false, others:"..."}

  -- condition checklist
  condition_checklist jsonb default '{}'::jsonb,
  -- {screen:"good", camera:"faulty", battery:"weak", speaker:"good", microphone:"good",
  --  charging_port:"good", buttons:"good", water_damage:false, body_condition:"scratched", display_condition:"cracked"}

  problem_description text not null,
  technician_notes text,

  estimated_cost numeric(12,2),
  estimated_delivery_date date,

  stage repair_stage not null default 'received',
  progress_percent int not null default 0,

  qr_code_token text unique not null default encode(gen_random_bytes(12), 'hex'),

  customer_signature_url text,
  received_at timestamptz default now(),
  delivered_at timestamptz,

  created_by uuid references shop_staff(id),
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  deleted_at timestamptz,

  unique(shop_id, job_number)
);
create index idx_jobs_shop_stage on repair_jobs(shop_id, stage);
create index idx_jobs_qr_token on repair_jobs(qr_code_token);
create index idx_jobs_customer on repair_jobs(customer_id);

create table job_photos (
  id uuid primary key default uuid_generate_v4(),
  job_id uuid references repair_jobs(id) on delete cascade,
  photo_type text not null, -- front, back, left, right, top, bottom, damage
  storage_path text not null,
  uploaded_at timestamptz default now()
);

create table job_status_history (
  id uuid primary key default uuid_generate_v4(),
  job_id uuid references repair_jobs(id) on delete cascade,
  from_stage repair_stage,
  to_stage repair_stage not null,
  progress_percent int,
  note text,
  changed_by uuid references shop_staff(id),
  changed_at timestamptz default now(),
  notified_channels notification_channel[]
);

-- ============================================================
-- INVOICING & PAYMENTS
-- ============================================================
create table invoices (
  id uuid primary key default uuid_generate_v4(),
  shop_id uuid references shops(id) on delete cascade,
  job_id uuid references repair_jobs(id),
  invoice_number text not null,
  labor_charges numeric(12,2) default 0,
  parts_charges numeric(12,2) default 0,
  discount numeric(12,2) default 0,
  gst_percent numeric(5,2) default 18.00,
  gst_amount numeric(12,2) generated always as
    (round(((labor_charges + parts_charges - discount) * gst_percent / 100), 2)) stored,
  total_amount numeric(12,2) generated always as
    (labor_charges + parts_charges - discount +
     round(((labor_charges + parts_charges - discount) * gst_percent / 100), 2)) stored,
  advance_paid numeric(12,2) default 0,
  balance_due numeric(12,2) generated always as
    (labor_charges + parts_charges - discount +
     round(((labor_charges + parts_charges - discount) * gst_percent / 100), 2)
     - advance_paid) stored,
  payment_status payment_status default 'pending',
  pdf_url text,
  created_at timestamptz default now(),
  unique(shop_id, invoice_number)
);

create table invoice_line_items (
  id uuid primary key default uuid_generate_v4(),
  invoice_id uuid references invoices(id) on delete cascade,
  description text not null,
  item_type text not null default 'part', -- part | labor | other
  quantity numeric(10,2) default 1,
  unit_price numeric(12,2) not null,
  amount numeric(12,2) generated always as (quantity * unit_price) stored
);

create table payments (
  id uuid primary key default uuid_generate_v4(),
  shop_id uuid references shops(id) on delete cascade,
  invoice_id uuid references invoices(id),
  amount numeric(12,2) not null,
  method payment_method not null,
  reference_no text,
  is_refund boolean default false,
  received_by uuid references shop_staff(id),
  paid_at timestamptz default now()
);

-- ============================================================
-- WARRANTY
-- ============================================================
create table warranties (
  id uuid primary key default uuid_generate_v4(),
  job_id uuid references repair_jobs(id),
  warranty_days int not null default 90,
  starts_at date not null,
  expires_at date generated always as (starts_at + (warranty_days || ' days')::interval) stored,
  covered_parts text[],
  terms text
);

create table warranty_claims (
  id uuid primary key default uuid_generate_v4(),
  warranty_id uuid references warranties(id),
  new_job_id uuid references repair_jobs(id), -- linked replacement job
  claim_reason text,
  status text default 'open', -- open, approved, rejected, resolved
  created_at timestamptz default now()
);

-- ============================================================
-- INVENTORY
-- ============================================================
create table suppliers (
  id uuid primary key default uuid_generate_v4(),
  shop_id uuid references shops(id) on delete cascade,
  name text not null, phone text, email text, address text
);

create table inventory_items (
  id uuid primary key default uuid_generate_v4(),
  shop_id uuid references shops(id) on delete cascade,
  sku text not null,
  name text not null,
  category text, -- display, battery, charging_port, camera, ic, speaker, mic, flex_cable, other
  compatible_models text[],
  quantity_in_stock int not null default 0,
  low_stock_threshold int default 5,
  unit_cost numeric(12,2),
  unit_price numeric(12,2),
  barcode text,
  qr_code text,
  supplier_id uuid references suppliers(id),
  created_at timestamptz default now(),
  unique(shop_id, sku)
);

create table stock_movements (
  id uuid primary key default uuid_generate_v4(),
  item_id uuid references inventory_items(id) on delete cascade,
  movement_type text not null, -- stock_in, stock_out, adjustment
  quantity int not null,
  job_id uuid references repair_jobs(id),  -- if stock_out used in a repair
  purchase_reference text,
  moved_by uuid references shop_staff(id),
  moved_at timestamptz default now()
);

-- ============================================================
-- NOTIFICATIONS & AUDIT
-- ============================================================
create table notification_log (
  id uuid primary key default uuid_generate_v4(),
  shop_id uuid references shops(id) on delete cascade,
  job_id uuid references repair_jobs(id),
  channel notification_channel not null,
  recipient text not null,
  template text not null,
  payload jsonb,
  status text default 'queued', -- queued, sent, failed
  sent_at timestamptz,
  created_at timestamptz default now()
);

create table audit_logs (
  id uuid primary key default uuid_generate_v4(),
  shop_id uuid references shops(id) on delete cascade,
  actor_id uuid references shop_staff(id),
  action text not null,       -- e.g. 'job.status_changed', 'invoice.created'
  entity_table text not null,
  entity_id uuid not null,
  before jsonb,
  after jsonb,
  created_at timestamptz default now()
);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table shops enable row level security;
alter table shop_staff enable row level security;
alter table customers enable row level security;
alter table repair_jobs enable row level security;
alter table job_photos enable row level security;
alter table invoices enable row level security;
alter table payments enable row level security;
alter table inventory_items enable row level security;

-- helper: is the current user staff of this shop?
create or replace function is_shop_staff(target_shop_id uuid)
returns boolean language sql stable as $$
  select exists (
    select 1 from shop_staff
    where shop_id = target_shop_id
      and user_id = auth.uid()
      and is_active = true
  );
$$;

create policy "staff full access to own shop - jobs"
  on repair_jobs for all
  using (is_shop_staff(shop_id))
  with check (is_shop_staff(shop_id));

create policy "staff full access to own shop - customers"
  on customers for all
  using (is_shop_staff(shop_id))
  with check (is_shop_staff(shop_id));

create policy "staff access invoices"
  on invoices for all
  using (is_shop_staff(shop_id))
  with check (is_shop_staff(shop_id));

-- Public read for QR tracking page (no auth) — restricted view, see Section 5.2
create policy "public can view job by qr token via RPC only"
  on repair_jobs for select
  using (false); -- direct table access blocked; tracking goes through SECURITY DEFINER RPC below
```

### 2.1 Auto Job/Invoice Numbering (trigger example)

```sql
create sequence if not exists job_number_seq;

create or replace function generate_job_number()
returns trigger language plpgsql as $$
declare
  prefix text;
begin
  select job_prefix into prefix from shops where id = new.shop_id;
  new.job_number := coalesce(prefix, 'JOB') || '-' || to_char(now(),'YYYY') || '-' ||
                     lpad(nextval('job_number_seq')::text, 6, '0');
  return new;
end;
$$;

create trigger trg_job_number
  before insert on repair_jobs
  for each row when (new.job_number is null)
  execute function generate_job_number();
```

---

## 3. Entity Relationship Overview

```
shops (1) ──< shop_staff >── (M) auth.users
shops (1) ──< customers
shops (1) ──< repair_jobs >── (1) customers
repair_jobs (1) ──< job_photos
repair_jobs (1) ──< job_status_history
repair_jobs (1) ──< invoices (1) ──< invoice_line_items
invoices (1) ──< payments
repair_jobs (1) ──< warranties (1) ──< warranty_claims
shops (1) ──< inventory_items >── (1) suppliers
inventory_items (1) ──< stock_movements >── (0..1) repair_jobs
repair_jobs (1) ──< notification_log
shops (1) ──< audit_logs
```

Key cardinalities: one job → one invoice (1:1, re-billable via new invoice if reopened), one job → many status history rows (full timeline), one job → many photos, one customer → many jobs (repair history).

---

## 4. Flutter Project Structure (Clean Architecture)

```
repair_flow/
├── lib/
│   ├── main.dart
│   ├── app/
│   │   ├── app.dart                     # MaterialApp.router, theme, locale
│   │   ├── router/
│   │   │   ├── app_router.dart          # go_router config, role-based guards
│   │   │   └── route_names.dart
│   │   └── theme/
│   │       ├── app_colors.dart
│   │       ├── app_typography.dart
│   │       └── app_theme.dart
│   │
│   ├── core/
│   │   ├── constants/
│   │   ├── errors/                      # Failure, Exception classes
│   │   ├── network/                     # Supabase client provider, connectivity
│   │   ├── usecases/                    # UseCase<T, Params> base class
│   │   ├── utils/                       # formatters, validators, encryption helpers
│   │   └── widgets/                     # shared design-system widgets (buttons, cards, chips)
│   │
│   ├── features/
│   │   ├── auth/
│   │   │   ├── data/
│   │   │   │   ├── datasources/auth_remote_datasource.dart
│   │   │   │   ├── models/user_model.dart
│   │   │   │   └── repositories/auth_repository_impl.dart
│   │   │   ├── domain/
│   │   │   │   ├── entities/user_entity.dart
│   │   │   │   ├── repositories/auth_repository.dart
│   │   │   │   └── usecases/{sign_in.dart, sign_out.dart, get_current_role.dart}
│   │   │   └── presentation/
│   │   │       ├── providers/auth_provider.dart      # Riverpod
│   │   │       ├── screens/{login_screen.dart, role_gate.dart}
│   │   │       └── widgets/
│   │   │
│   │   ├── customers/
│   │   │   ├── data/  (datasources, models, repositories)
│   │   │   ├── domain/ (entities, repositories, usecases)
│   │   │   └── presentation/
│   │   │       ├── screens/{customer_list_screen.dart, customer_detail_screen.dart, customer_form_screen.dart}
│   │   │       └── widgets/{customer_card.dart, repair_history_tile.dart}
│   │   │
│   │   ├── device_intake/
│   │   │   ├── data/
│   │   │   ├── domain/
│   │   │   └── presentation/
│   │   │       ├── screens/
│   │   │       │   ├── intake_wizard_screen.dart      # multi-step form
│   │   │       │   ├── steps/customer_step.dart
│   │   │       │   ├── steps/device_details_step.dart
│   │   │       │   ├── steps/condition_checklist_step.dart
│   │   │       │   ├── steps/photo_capture_step.dart
│   │   │       │   └── steps/signature_step.dart
│   │   │       └── widgets/{condition_toggle.dart, accessory_checkbox_group.dart}
│   │   │
│   │   ├── repair_jobs/
│   │   │   ├── data/
│   │   │   ├── domain/
│   │   │   └── presentation/
│   │   │       ├── screens/{job_list_screen.dart, job_detail_screen.dart, kanban_board_screen.dart}
│   │   │       └── widgets/{stage_stepper.dart, job_card.dart, status_update_sheet.dart}
│   │   │
│   │   ├── qr_tracking/                 # PUBLIC-facing, no auth
│   │   │   ├── data/
│   │   │   ├── domain/
│   │   │   └── presentation/
│   │   │       └── screens/tracking_screen.dart       # web-deep-link target
│   │   │
│   │   ├── technicians/
│   │   ├── billing/
│   │   │   └── presentation/screens/{invoice_builder_screen.dart, invoice_preview_screen.dart}
│   │   ├── payments/
│   │   ├── inventory/
│   │   ├── warranty/
│   │   ├── notifications/
│   │   ├── reports/
│   │   ├── customer_portal/
│   │   └── settings/
│   │
│   ├── shared/
│   │   ├── pdf/                         # receipt/invoice PDF generators
│   │   ├── qr/                          # QR generation/scan helpers
│   │   ├── realtime/                    # Supabase realtime channel wrappers
│   │   └── models/                      # cross-feature DTOs
│   │
│   └── l10n/
│
├── test/
│   ├── unit/  ├── widget/  └── integration/
├── supabase/
│   ├── migrations/                      # SQL from Section 2, versioned
│   ├── functions/                       # Edge Functions (Deno) — see Section 5
│   └── seed.sql
├── assets/{images, fonts, icons}
└── pubspec.yaml
```

**Key packages:** `flutter_riverpod`, `go_router`, `supabase_flutter`, `freezed` + `json_serializable`, `qr_flutter` + `mobile_scanner`, `pdf` + `printing`, `signature`, `image_picker`/`camera`, `fl_chart`, `drift` (offline cache), `flutter_local_notifications`, `intl`.

---

## 5. API / Edge Function Contracts

Supabase gives you auto-generated REST + realtime on every table (governed by RLS above). Custom business logic lives in **Postgres RPC functions** (called via `supabase.rpc()`) and **Edge Functions** (Deno, for third-party calls like WhatsApp/SMS).

### 5.1 RPC: create a repair job atomically
```sql
create or replace function create_repair_job(payload jsonb)
returns repair_jobs
language plpgsql security invoker as $$
declare
  new_job repair_jobs;
begin
  insert into repair_jobs (
    shop_id, customer_id, brand, model, imei, serial_number, color,
    storage_variant, lock_type, sim_available, memory_card_available,
    accessories, condition_checklist, problem_description,
    estimated_cost, estimated_delivery_date, created_by
  )
  select
    (payload->>'shop_id')::uuid, (payload->>'customer_id')::uuid,
    payload->>'brand', payload->>'model', payload->>'imei', payload->>'serial_number',
    payload->>'color', payload->>'storage_variant',
    (payload->>'lock_type')::lock_type,
    (payload->>'sim_available')::boolean, (payload->>'memory_card_available')::boolean,
    payload->'accessories', payload->'condition_checklist', payload->>'problem_description',
    (payload->>'estimated_cost')::numeric, (payload->>'estimated_delivery_date')::date,
    (payload->>'created_by')::uuid
  returning * into new_job;

  insert into job_status_history(job_id, from_stage, to_stage, changed_by, note)
  values (new_job.id, null, 'received', new_job.created_by, 'Device intake completed');

  return new_job;
end;
$$;
```

### 5.2 RPC: public QR tracking lookup (SECURITY DEFINER, minimal fields only)
```sql
create or replace function get_job_by_qr(token text)
returns table (
  job_number text, stage repair_stage, progress_percent int,
  customer_name text, device_model text, technician_name text,
  estimated_delivery_date date, payment_status payment_status,
  warranty_expires_at date, timeline jsonb
)
language plpgsql security definer as $$
begin
  return query
  select rj.job_number, rj.stage, rj.progress_percent,
         c.full_name, rj.model, st.full_name,
         rj.estimated_delivery_date,
         coalesce(inv.payment_status, 'pending'),
         w.expires_at,
         (select jsonb_agg(jsonb_build_object(
             'stage', h.to_stage, 'at', h.changed_at, 'note', h.note
          ) order by h.changed_at)
          from job_status_history h where h.job_id = rj.id)
  from repair_jobs rj
  join customers c on c.id = rj.customer_id
  left join shop_staff st on st.id = rj.assigned_technician_id
  left join invoices inv on inv.job_id = rj.id
  left join warranties w on w.job_id = rj.id
  where rj.qr_code_token = token and rj.deleted_at is null;
end;
$$;

grant execute on function get_job_by_qr(text) to anon;
```
This is the *only* thing the public tracking page can call — no direct table grants to `anon`, so a customer never sees another customer's data even with a guessed token (128-bit random token = effectively unguessable).

### 5.3 RPC: update repair stage (+ triggers notification)
```sql
create or replace function update_job_stage(
  p_job_id uuid, p_new_stage repair_stage, p_note text, p_actor uuid
) returns void language plpgsql as $$
declare v_old repair_stage;
begin
  select stage into v_old from repair_jobs where id = p_job_id;

  update repair_jobs
  set stage = p_new_stage,
      progress_percent = case p_new_stage
        when 'received' then 10 when 'diagnosing' then 20
        when 'waiting_approval' then 30 when 'waiting_spare_parts' then 40
        when 'in_progress' then 60 when 'testing' then 80
        when 'ready' then 95 when 'delivered' then 100 else progress_percent end,
      delivered_at = case when p_new_stage = 'delivered' then now() else delivered_at end,
      updated_at = now()
  where id = p_job_id;

  insert into job_status_history(job_id, from_stage, to_stage, note, changed_by)
  values (p_job_id, v_old, p_new_stage, p_note, p_actor);

  -- enqueue notification row; an Edge Function cron/webhook picks these up and sends
  insert into notification_log(shop_id, job_id, channel, recipient, template, payload)
  select rj.shop_id, rj.id, 'whatsapp', c.mobile, 'stage_update',
         jsonb_build_object('stage', p_new_stage, 'job_number', rj.job_number)
  from repair_jobs rj join customers c on c.id = rj.customer_id
  where rj.id = p_job_id;
end;
$$;
```

### 5.4 Edge Function: `send-notification` (Deno, called by DB webhook on `notification_log` insert)
```
POST /functions/v1/send-notification
Body: { "record": { "id", "channel", "recipient", "template", "payload" } }

Responsibilities:
  - channel = whatsapp → call WhatsApp Business Cloud API (template message)
  - channel = sms      → call SMS gateway (e.g. Twilio / MSG91)
  - channel = email    → call Resend/SendGrid with rendered HTML
  - channel = push     → call FCM/APNs via Supabase push
  - update notification_log.status + sent_at
```

### 5.5 Edge Function: `generate-invoice-pdf`
```
POST /functions/v1/generate-invoice-pdf
Body: { "invoice_id": uuid }
→ renders invoice HTML template → Puppeteer/PDF lib → uploads to Storage bucket
  "invoices/{shop_id}/{invoice_number}.pdf" → returns signed URL
```

### 5.6 Realtime channels (client-side)
```dart
supabase
  .channel('job_${jobId}')
  .onPostgresChanges(
    event: PostgresChangeEvent.update,
    schema: 'public', table: 'repair_jobs',
    filter: PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: 'id', value: jobId),
    callback: (payload) => updateLocalJobState(payload.newRecord),
  ).subscribe();
```
Used for: live Kanban board (admin/technician), live tracking page, live technician job-queue badge counts.

### 5.7 Storage Buckets
| Bucket | Access | Contents |
|---|---|---|
| `device-photos` | Private, signed URLs | Intake photos |
| `signatures` | Private | Customer signature PNGs |
| `invoices` | Private, signed URLs | Generated PDFs |
| `receipts` | Private, signed URLs | Generated PDFs |
| `shop-assets` | Public | Logos |

---

## 6. Screen Flow & Wireframe Specs

### 6.1 App-level flow
```
Splash → Auth Check
  ├─ Not logged in → Login Screen → Role resolved from shop_staff → Route by role
  └─ Logged in → Role Gate
        ├─ Admin/Manager → Dashboard (KPIs, quick actions)
        ├─ Receptionist  → Job Queue + New Intake shortcut
        └─ Technician    → My Jobs Queue

Public (no auth): /track/:token → QR Tracking Screen
Public (no auth): /portal/login → Customer Portal (Phase 2)
```

### 6.2 Admin Dashboard (layout spec)
```
┌─────────────────────────────────────────────────────────┐
│ AppBar: Shop name ▾   [Search]        [🔔3]  [Profile]  │
├───────────┬─────────────────────────────────────────────┤
│ Sidebar   │  KPI Row: Today's Jobs | Revenue | Pending   │
│ Dashboard │           | Ready for Pickup | Low Stock ⚠  │
│ Jobs      │  ──────────────────────────────────────────  │
│ Customers │  Repair Pipeline (Kanban, drag to change     │
│ Technicians│  stage): Received | Diagnosing | Waiting    │
│ Billing   │  Parts | In Progress | Testing | Ready       │
│ Inventory │  ──────────────────────────────────────────  │
│ Reports   │  Revenue chart (7/30/90d toggle)             │
│ Settings  │  Recent activity feed                        │
└───────────┴─────────────────────────────────────────────┘
Responsive: sidebar collapses to bottom nav (mobile) / drawer (tablet)
```

### 6.3 Device Intake Wizard (5 steps, linear stepper, autosave draft each step)
```
Step 1 — Customer        : search existing (mobile lookup) or quick-add new
Step 2 — Device Details  : brand/model dropdown (searchable), IMEI (camera OCR optional),
                            serial, color, storage, lock type + secret (masked input)
Step 3 — Condition       : checklist grid (toggle chips: Good/Faulty/N.A. per item),
                            accessories received (checkboxes), water damage switch
Step 4 — Photos & Problem: 6 guided photo slots (front/back/L/R/top/bottom) + damage
                            photos (multi), problem description (voice-to-text option),
                            estimated cost, estimated delivery date picker
Step 5 — Signature & Confirm: signature pad, terms checkbox, "Generate Receipt" CTA
                            → creates job → shows receipt preview → share sheet
                            (WhatsApp/SMS/Email/PDF/Print)
```

### 6.4 Job Detail Screen
```
Header: Job # · Status chip · Progress bar
Tabs: [Overview] [Device Info] [Photos] [Timeline] [Invoice] [Notes]
Overview: customer card, device summary, assigned technician (reassign dropdown),
          stage stepper with "Update Stage" action → bottom sheet (select stage,
          add note, auto-notify toggle)
Timeline: vertical timeline of job_status_history with timestamps + actor
```

### 6.5 QR Public Tracking Screen (customer-facing, mobile-first web)
```
┌───────────────────────────────┐
│   [Shop Logo]  Shop Name       │
│   Job #JOB-2026-000123         │
│                                 │
│   ●───●───●───○───○───○───○   │
│   Received Diagnosing InProg.. │
│   (progress bar 60%)           │
│                                 │
│   Device: iPhone 13 Pro (Blue) │
│   Technician: Rahul S.         │
│   Est. Delivery: 05 Jul 2026   │
│   Payment: ₹1,200 pending      │
│   Warranty: 90 days on repair  │
│                                 │
│   Timeline (expandable)        │
│   [Contact Shop] [Call] [Share]│
└───────────────────────────────┘
```

### 6.6 Technician Dashboard
```
My Jobs (filter: Today / All Active) — card list sorted by priority/due date
Each card: device + problem summary, stage dropdown (quick update), "Log Parts Used"
           button → deducts inventory, "Add Note/Photo" button
Daily Task summary strip at top: Assigned X | In Progress Y | Completed Today Z
```

### 6.7 Invoice Builder Screen
```
Left: line items table (add part [autocomplete from inventory] / add labor row)
Right: live summary — Subtotal, Discount (%/₹ toggle), GST %, Total, Advance,
       Balance Due — recalculates live
Bottom: Save Draft | Generate & Send (creates PDF, opens share sheet)
```

### 6.8 Customer Portal (Phase 2)
```
Login (mobile OTP) → My Repairs (list, tap → tracking detail) →
Invoices & Receipts (download) → Warranty (active list with expiry countdown) →
Payment History → Support (chat/call shop)
```

---

## 7. Repair Workflow & Notification Logic

### 7.1 Stage machine
```
received → diagnosing → waiting_approval ⇄ waiting_spare_parts → in_progress
  → testing → ready → delivered
(cancelled reachable from any pre-delivered state)
```
Enforce valid transitions in `update_job_stage` (add a `valid_transitions` lookup table if you want to hard-block skips vs. just warn — recommend **warn, don't block**, since real shops skip stages).

### 7.2 Notification triggers → channel → template
| Event | Channels | Template |
|---|---|---|
| Job received | WhatsApp, SMS | "We've received your {model}, Job #{job_number}. Track: {link}" |
| Stage change | WhatsApp | "{job_number} status: {stage}. {link}" |
| Ready for pickup | WhatsApp, SMS, Push | "Your {model} is ready! Balance due: ₹{balance}" |
| Invoice generated | Email, WhatsApp | Invoice PDF attached/linked |
| Payment received | SMS | Receipt confirmation |
| Warranty expiring (7d before) | Email, Push | Cron job scans `warranties.expires_at` |

Notification dispatch is decoupled via the `notification_log` table + DB webhook → Edge Function, so retries/failures don't block the main transaction.

---

## 8. Design System

```
Colors
  primary:      #2563EB (trust blue)
  primary-dark: #1E40AF
  success:      #16A34A (ready/delivered)
  warning:      #F59E0B (waiting parts/approval)
  danger:       #DC2626 (cancelled/overdue)
  neutral-900:  #111827   neutral-500: #6B7280   neutral-100: #F3F4F6
  surface:      #FFFFFF   background: #F9FAFB

Typography (Inter / SF Pro fallback)
  Display   32/40  700
  H1        24/32  700
  H2        20/28  600
  Body      15/22  400
  Caption   13/18  500

Spacing scale: 4 / 8 / 12 / 16 / 24 / 32 / 48
Radius: cards 16px, buttons 12px, chips 999px (pill)
Elevation: subtle shadow (0 1px 3px rgba(0,0,0,.08)) — avoid heavy material shadows for a "premium SaaS" feel
Stage color mapping (chips): received=neutral, diagnosing=blue, waiting_*=amber,
  in_progress=indigo, testing=purple, ready=green, delivered=success-dark, cancelled=red
```
Responsive breakpoints: mobile <600, tablet 600–1024, desktop >1024 — sidebar nav collapses to bottom nav/drawer below 1024.

---

## 9. Production Deployment Guide

### 9.1 Supabase
1. Create project → run migrations in `supabase/migrations` via `supabase db push`
2. Enable pgcrypto, set up Storage buckets per Section 5.7 with signed-URL-only policies
3. Deploy Edge Functions: `supabase functions deploy send-notification generate-invoice-pdf`
4. Set secrets: `supabase secrets set WHATSAPP_TOKEN=... SMS_API_KEY=... RESEND_API_KEY=...`
5. Configure DB Webhook: `notification_log` INSERT → `send-notification` function
6. Enable Point-in-Time-Recovery backups (paid tier) + nightly `pg_dump` cron to S3/Backblaze as secondary
7. Turn on Realtime for `repair_jobs`, `job_status_history`, `notification_log`

### 9.2 Flutter builds
```bash
# Mobile
flutter build apk --release --flavor production
flutter build ipa --release

# Web
flutter build web --release --wasm   # or --web-renderer canvaskit for pixel-perfect
# deploy /build/web to Vercel/Netlify/Cloudflare Pages/Supabase Storage+CDN

# Desktop
flutter build windows --release
flutter build macos --release
flutter build linux --release
```
- Use `--dart-define` (or `.env` + `flutter_dotenv`) for `SUPABASE_URL` / `SUPABASE_ANON_KEY` per environment (dev/staging/prod)
- Code-sign macOS (notarization) and Windows (EV cert) builds before distribution
- Web: set correct CORS + Content-Security-Policy on hosting for Supabase Storage domain

### 9.3 CI/CD (suggested)
GitHub Actions: on `main` push → `flutter analyze` → `flutter test` → build matrix (android/ios/web/windows/macos/linux) → upload artifacts → (mobile) Fastlane to TestFlight/Play internal track → (web) auto-deploy to hosting.

### 9.4 Monitoring
- Sentry (Flutter + Edge Functions) for crash/error tracking
- Supabase built-in logs/metrics dashboard for DB load and slow queries
- Uptime monitor (e.g. Better Uptime) pinging `get_job_by_qr` RPC endpoint as a health check

---

## 10. Suggested Build Roadmap

| Sprint | Focus |
|---|---|
| 1–2 | Supabase schema + RLS, Auth, role gate, design system, app shell/nav |
| 3–4 | Customer management, Device intake wizard (photos+signature+QR gen) |
| 5–6 | Job list/Kanban, status workflow, timeline, realtime sync |
| 7 | QR public tracking page (web), notification pipeline (WhatsApp/SMS/Email) |
| 8–9 | Invoicing, payments, PDF generation/sharing |
| 10 | Technician dashboard, job queue, reports v1 |
| 11 | Inventory module, stock alerts |
| 12 | Warranty module, customer portal v1 |
| 13 | Reports & analytics, Excel export |
| 14 | Hardening: audit logs, backups, load testing, security review |
| 15 | Beta rollout to 2–3 pilot shops → feedback → GA |

---

*Next step, pick one and I'll build it in full: (1) interactive clickable admin dashboard + tracking page mockup, (2) working Flutter starter repo (auth + customer + intake modules wired to a real Supabase project), or (3) the receipt/invoice PDF template.*
