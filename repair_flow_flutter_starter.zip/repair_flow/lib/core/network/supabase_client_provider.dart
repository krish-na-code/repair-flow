import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Initializes and exposes the single Supabase client used across the app.
/// Call [initSupabase] once in main() before runApp().
class SupabaseInit {
  static Future<void> initSupabase() async {
    await dotenv.load(fileName: '.env');

    await Supabase.initialize(
      url: dotenv.env['SUPABASE_URL']!,
      anonKey: dotenv.env['SUPABASE_ANON_KEY']!,
    );
  }
}

/// Shorthand accessor used throughout data sources.
SupabaseClient get supabase => Supabase.instance.client;
