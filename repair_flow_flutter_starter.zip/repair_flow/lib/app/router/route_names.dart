class RouteNames {
  static const login = '/login';
  static const jobs = '/jobs';
  static const customers = '/customers';
  static const intake = '/intake';
  static const billing = '/billing';
}
