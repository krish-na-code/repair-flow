import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/presentation/providers/auth_provider.dart';
import '../../features/auth/presentation/screens/login_screen.dart';
import '../../features/customers/presentation/screens/customer_list_screen.dart';
import '../../features/repair_jobs/presentation/screens/job_list_screen.dart';
import 'route_names.dart';

/// Riverpod-aware GoRouter: redirects to /login whenever there's no
/// authenticated staff user, and away from /login once there is one.
/// Extend this with role checks (e.g. block Technicians from /billing)
/// once those screens exist.
final appRouterProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authStateProvider);

  return GoRouter(
    initialLocation: RouteNames.jobs,
    redirect: (context, state) {
      final isLoggedIn = authState.valueOrNull != null;
      final isLoggingIn = state.matchedLocation == RouteNames.login;

      if (!isLoggedIn && !isLoggingIn) return RouteNames.login;
      if (isLoggedIn && isLoggingIn) return RouteNames.jobs;
      return null;
    },
    routes: [
      GoRoute(path: RouteNames.login, builder: (context, state) => const LoginScreen()),
      GoRoute(path: RouteNames.jobs, builder: (context, state) => const JobListScreen()),
      GoRoute(path: RouteNames.customers, builder: (context, state) => const CustomerListScreen()),
    ],
  );
});
