import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/entities/repair_job.dart';
import '../providers/repair_job_provider.dart';
import '../widgets/job_card.dart';
import '../widgets/status_update_sheet.dart';

class JobListScreen extends ConsumerWidget {
  const JobListScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final jobsAsync = ref.watch(jobListProvider);
    final activeFilter = ref.watch(jobStageFilterProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Repair jobs')),
      body: Column(
        children: [
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [
                _FilterChip(label: 'All', selected: activeFilter == null, onTap: () {
                  ref.read(jobStageFilterProvider.notifier).state = null;
                }),
                for (final stage in RepairStage.values.where((s) => s != RepairStage.cancelled))
                  _FilterChip(
                    label: stage.label,
                    selected: activeFilter == stage,
                    onTap: () => ref.read(jobStageFilterProvider.notifier).state = stage,
                  ),
              ],
            ),
          ),
          const Divider(height: 1),
          Expanded(
            child: jobsAsync.when(
              data: (jobs) {
                if (jobs.isEmpty) return const Center(child: Text('No jobs in this stage.'));
                return ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: jobs.length,
                  itemBuilder: (context, index) {
                    final job = jobs[index];
                    return JobCard(
                      job: job,
                      onTap: () => showModalBottomSheet(
                        context: context,
                        isScrollControlled: true,
                        builder: (_) => StatusUpdateSheet(job: job),
                      ),
                    );
                  },
                );
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (error, _) => Center(child: Text('Failed to load jobs: $error')),
            ),
          ),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _FilterChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
      child: ChoiceChip(label: Text(label), selected: selected, onSelected: (_) => onTap()),
    );
  }
}
