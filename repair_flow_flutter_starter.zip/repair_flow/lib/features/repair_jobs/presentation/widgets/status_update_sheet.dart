import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../auth/presentation/providers/auth_provider.dart';
import '../../domain/entities/repair_job.dart';
import '../providers/repair_job_provider.dart';

class StatusUpdateSheet extends ConsumerStatefulWidget {
  final RepairJob job;

  const StatusUpdateSheet({super.key, required this.job});

  @override
  ConsumerState<StatusUpdateSheet> createState() => _StatusUpdateSheetState();
}

class _StatusUpdateSheetState extends ConsumerState<StatusUpdateSheet> {
  late RepairStage _selectedStage = widget.job.stage;
  final _noteController = TextEditingController();
  bool _isSaving = false;

  Future<void> _confirm() async {
    final actorId = ref.read(currentStaffUserProvider)?.id;
    if (actorId == null) return;

    setState(() => _isSaving = true);

    final result = await ref.read(repairJobRepositoryProvider).updateStage(
          jobId: widget.job.id,
          newStage: _selectedStage,
          actorStaffId: actorId,
          note: _noteController.text.trim().isEmpty ? null : _noteController.text.trim(),
        );

    if (!mounted) return;
    setState(() => _isSaving = false);

    result.when(
      ok: (_) {
        ref.invalidate(jobListProvider);
        Navigator.of(context).pop();
      },
      err: (failure) =>
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(failure.message))),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        left: 20,
        right: 20,
        top: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'Update status — ${widget.job.jobNumber}',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: RepairStage.values
                .map((stage) => ChoiceChip(
                      label: Text(stage.label),
                      selected: _selectedStage == stage,
                      onSelected: (_) => setState(() => _selectedStage = stage),
                    ))
                .toList(),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: _noteController,
            decoration: const InputDecoration(labelText: 'Note (optional)'),
            maxLines: 2,
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              const Icon(Icons.notifications_active_outlined, size: 18),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  'Customer will be notified automatically via WhatsApp/SMS.',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: _isSaving ? null : _confirm,
            child: _isSaving
                ? const SizedBox(
                    height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Update status'),
          ),
        ],
      ),
    );
  }
}
