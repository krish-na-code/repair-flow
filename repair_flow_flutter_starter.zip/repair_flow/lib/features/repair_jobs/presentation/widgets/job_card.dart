import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../domain/entities/repair_job.dart';

class JobCard extends StatelessWidget {
  final RepairJob job;
  final VoidCallback onTap;

  const JobCard({super.key, required this.job, required this.onTap});

  Color _stageColor(BuildContext context, RepairStage stage) {
    final scheme = Theme.of(context).colorScheme;
    switch (stage) {
      case RepairStage.ready:
      case RepairStage.delivered:
        return Colors.green;
      case RepairStage.waitingApproval:
      case RepairStage.waitingSpareParts:
        return Colors.amber.shade800;
      case RepairStage.cancelled:
        return scheme.error;
      default:
        return scheme.primary;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _stageColor(context, job.stage);

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(job.jobNumber, style: const TextStyle(fontWeight: FontWeight.w600)),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: color.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      job.stage.label,
                      style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text('${job.customerName} · ${job.brand ?? ''} ${job.model ?? ''}'.trim()),
              const SizedBox(height: 4),
              Text(
                job.problemDescription,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 8),
              LinearProgressIndicator(value: job.progressPercent / 100, minHeight: 4),
              if (job.estimatedDeliveryDate != null) ...[
                const SizedBox(height: 6),
                Text(
                  'Est. delivery: ${DateFormat.yMMMd().format(job.estimatedDeliveryDate!)}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
