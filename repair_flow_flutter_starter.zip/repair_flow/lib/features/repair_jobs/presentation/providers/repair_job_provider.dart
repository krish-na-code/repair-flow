import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/network/supabase_client_provider.dart';
import '../../data/repositories/repair_job_repository.dart';
import '../../domain/entities/repair_job.dart';

final repairJobRepositoryProvider = Provider((ref) => RepairJobRepository());

final jobStageFilterProvider = StateProvider<RepairStage?>((ref) => null);

final jobListProvider = FutureProvider.autoDispose<List<RepairJob>>((ref) async {
  final stageFilter = ref.watch(jobStageFilterProvider);
  final repository = ref.watch(repairJobRepositoryProvider);

  // Re-run this provider whenever repair_jobs changes anywhere in the shop,
  // so every open screen (Kanban, list, dashboard counts) stays live.
  final channel = supabase.channel('repair_jobs_changes')
    ..onPostgresChanges(
      event: PostgresChangeEvent.all,
      schema: 'public',
      table: 'repair_jobs',
      callback: (_) => ref.invalidateSelf(),
    )
    ..subscribe();

  ref.onDispose(() => supabase.removeChannel(channel));

  final result = await repository.getJobs(filterByStage: stageFilter);
  return result.when(
    ok: (jobs) => jobs,
    err: (failure) => throw Exception(failure.message),
  );
});
