import '../../../../core/errors/failures.dart';
import '../../../../core/network/supabase_client_provider.dart';
import '../../../../core/utils/result.dart';
import '../../domain/entities/repair_job.dart';

class RepairJobRepository {
  Future<Result<List<RepairJob>>> getJobs({RepairStage? filterByStage}) async {
    try {
      var query = supabase
          .from('repair_jobs')
          .select('*, customers!inner(full_name)')
          .isFilter('deleted_at', null);

      if (filterByStage != null) {
        query = query.eq('stage', filterByStage.dbValue);
      }

      final rows = await query.order('received_at', ascending: false);

      return Result.ok(rows.map((row) => RepairJob.fromMap(row)).toList());
    } catch (e) {
      return Result.err(ServerFailure(e.toString()));
    }
  }

  /// Creates a job via the `create_repair_job` RPC (see API contracts,
  /// Section 5.1) so the job number, initial status history row, and
  /// QR token are generated atomically on the server.
  Future<Result<String>> createJob(Map<String, dynamic> payload) async {
    try {
      final row = await supabase.rpc('create_repair_job', params: {'payload': payload});
      return Result.ok(row['id'] as String);
    } catch (e) {
      return Result.err(ServerFailure(e.toString()));
    }
  }

  /// Updates stage via the `update_job_stage` RPC (Section 5.3), which
  /// also writes the status-history row and enqueues a customer notification —
  /// keeping that logic server-side means every client (mobile/web/desktop)
  /// behaves identically.
  Future<Result<void>> updateStage({
    required String jobId,
    required RepairStage newStage,
    required String actorStaffId,
    String? note,
  }) async {
    try {
      await supabase.rpc('update_job_stage', params: {
        'p_job_id': jobId,
        'p_new_stage': newStage.dbValue,
        'p_note': note,
        'p_actor': actorStaffId,
      });
      return const Result.ok(null);
    } catch (e) {
      return Result.err(ServerFailure(e.toString()));
    }
  }
}
