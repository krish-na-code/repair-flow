enum RepairStage {
  received,
  diagnosing,
  waitingApproval,
  waitingSpareParts,
  inProgress,
  testing,
  ready,
  delivered,
  cancelled,
}

extension RepairStageX on RepairStage {
  /// Matches the Postgres enum values in the `repair_stage` type (schema Section 2).
  String get dbValue {
    switch (this) {
      case RepairStage.received:
        return 'received';
      case RepairStage.diagnosing:
        return 'diagnosing';
      case RepairStage.waitingApproval:
        return 'waiting_approval';
      case RepairStage.waitingSpareParts:
        return 'waiting_spare_parts';
      case RepairStage.inProgress:
        return 'in_progress';
      case RepairStage.testing:
        return 'testing';
      case RepairStage.ready:
        return 'ready';
      case RepairStage.delivered:
        return 'delivered';
      case RepairStage.cancelled:
        return 'cancelled';
    }
  }

  String get label {
    switch (this) {
      case RepairStage.received:
        return 'Received';
      case RepairStage.diagnosing:
        return 'Diagnosing';
      case RepairStage.waitingApproval:
        return 'Waiting approval';
      case RepairStage.waitingSpareParts:
        return 'Waiting spare parts';
      case RepairStage.inProgress:
        return 'In progress';
      case RepairStage.testing:
        return 'Testing';
      case RepairStage.ready:
        return 'Ready';
      case RepairStage.delivered:
        return 'Delivered';
      case RepairStage.cancelled:
        return 'Cancelled';
    }
  }

  static RepairStage fromDb(String value) {
    return RepairStage.values.firstWhere(
      (s) => s.dbValue == value,
      orElse: () => RepairStage.received,
    );
  }
}

class RepairJob {
  final String id;
  final String jobNumber;
  final String customerId;
  final String customerName;
  final String? brand;
  final String? model;
  final String problemDescription;
  final RepairStage stage;
  final int progressPercent;
  final String qrCodeToken;
  final DateTime receivedAt;
  final DateTime? estimatedDeliveryDate;

  const RepairJob({
    required this.id,
    required this.jobNumber,
    required this.customerId,
    required this.customerName,
    this.brand,
    this.model,
    required this.problemDescription,
    required this.stage,
    required this.progressPercent,
    required this.qrCodeToken,
    required this.receivedAt,
    this.estimatedDeliveryDate,
  });

  factory RepairJob.fromMap(Map<String, dynamic> map) {
    return RepairJob(
      id: map['id'] as String,
      jobNumber: map['job_number'] as String,
      customerId: map['customer_id'] as String,
      // Populated via a join in the repository query (customers!inner(full_name)).
      customerName: (map['customers']?['full_name'] as String?) ?? 'Unknown',
      brand: map['brand'] as String?,
      model: map['model'] as String?,
      problemDescription: map['problem_description'] as String? ?? '',
      stage: RepairStageX.fromDb(map['stage'] as String),
      progressPercent: map['progress_percent'] as int? ?? 0,
      qrCodeToken: map['qr_code_token'] as String,
      receivedAt: DateTime.parse(map['received_at'] as String),
      estimatedDeliveryDate: map['estimated_delivery_date'] != null
          ? DateTime.parse(map['estimated_delivery_date'] as String)
          : null,
    );
  }
}
