import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/utils/result.dart';
import '../../data/repositories/auth_repository_impl.dart';
import '../../domain/entities/staff_user.dart';
import '../../domain/repositories/auth_repository.dart';

final authRepositoryProvider = Provider<AuthRepository>((ref) {
  return AuthRepositoryImpl();
});

/// Emits the current staff user (or null) any time auth state changes.
/// The router (see app_router.dart) listens to this to redirect between
/// the login screen and the role-appropriate home screen.
final authStateProvider = StreamProvider<StaffUser?>((ref) {
  return ref.watch(authRepositoryProvider).authStateChanges();
});

/// Convenience: current user without dealing with AsyncValue in every widget.
final currentStaffUserProvider = Provider<StaffUser?>((ref) {
  return ref.watch(authStateProvider).valueOrNull;
});

class AuthController extends StateNotifier<AsyncValue<StaffUser?>> {
  final AuthRepository _repository;

  AuthController(this._repository) : super(const AsyncValue.data(null));

  Future<void> signIn({required String email, required String password}) async {
    state = const AsyncValue.loading();
    final result = await _repository.signIn(email: email, password: password);
    state = result.when(
      ok: (user) => AsyncValue.data(user),
      err: (failure) => AsyncValue.error(failure.message, StackTrace.current),
    );
  }

  Future<void> signOut() async {
    await _repository.signOut();
    state = const AsyncValue.data(null);
  }
}

final authControllerProvider =
    StateNotifierProvider<AuthController, AsyncValue<StaffUser?>>((ref) {
  return AuthController(ref.watch(authRepositoryProvider));
});
