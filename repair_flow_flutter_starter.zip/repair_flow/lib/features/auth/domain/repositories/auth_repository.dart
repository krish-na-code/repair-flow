import '../../../../core/utils/result.dart';
import '../entities/staff_user.dart';

abstract class AuthRepository {
  Future<Result<StaffUser>> signIn({required String email, required String password});
  Future<void> signOut();
  Future<StaffUser?> getCurrentStaffUser();
  Stream<StaffUser?> authStateChanges();
}
