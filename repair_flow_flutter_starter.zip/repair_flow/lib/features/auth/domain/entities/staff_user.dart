enum StaffRole { admin, manager, technician, receptionist }

StaffRole staffRoleFromString(String value) {
  return StaffRole.values.firstWhere(
    (r) => r.name == value,
    orElse: () => StaffRole.receptionist,
  );
}

/// Represents the currently authenticated staff member, joined from
/// auth.users + shop_staff (see database schema, Section 2).
class StaffUser {
  final String id;
  final String shopId;
  final String fullName;
  final String email;
  final StaffRole role;

  const StaffUser({
    required this.id,
    required this.shopId,
    required this.fullName,
    required this.email,
    required this.role,
  });

  bool get isAdmin => role == StaffRole.admin;
  bool get isManager => role == StaffRole.manager;
  bool get isTechnician => role == StaffRole.technician;
  bool get isReceptionist => role == StaffRole.receptionist;

  /// Admin and Manager both get full back-office access.
  bool get canManageBilling => isAdmin || isManager;
  bool get canManageInventory => isAdmin || isManager;
}
