import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../../core/errors/failures.dart';
import '../../../../core/network/supabase_client_provider.dart';
import '../../../../core/utils/result.dart';
import '../../domain/entities/staff_user.dart';
import '../../domain/repositories/auth_repository.dart';

/// Talks to Supabase Auth for sign-in/out, then joins against `shop_staff`
/// to resolve the role and shop the user belongs to (see schema Section 2).
class AuthRepositoryImpl implements AuthRepository {
  @override
  Future<Result<StaffUser>> signIn({
    required String email,
    required String password,
  }) async {
    try {
      final response = await supabase.auth.signInWithPassword(
        email: email,
        password: password,
      );

      if (response.user == null) {
        return const Result.err(AuthFailure('Invalid email or password.'));
      }

      final staff = await _fetchStaffProfile(response.user!.id);
      if (staff == null) {
        await supabase.auth.signOut();
        return const Result.err(
          AuthFailure('This account is not linked to any shop staff record.'),
        );
      }

      return Result.ok(staff);
    } on AuthException catch (e) {
      return Result.err(AuthFailure(e.message));
    } catch (e) {
      return Result.err(ServerFailure(e.toString()));
    }
  }

  @override
  Future<void> signOut() => supabase.auth.signOut();

  @override
  Future<StaffUser?> getCurrentStaffUser() async {
    final user = supabase.auth.currentUser;
    if (user == null) return null;
    return _fetchStaffProfile(user.id);
  }

  @override
  Stream<StaffUser?> authStateChanges() {
    return supabase.auth.onAuthStateChange.asyncMap((event) async {
      final user = event.session?.user;
      if (user == null) return null;
      return _fetchStaffProfile(user.id);
    });
  }

  Future<StaffUser?> _fetchStaffProfile(String userId) async {
    final row = await supabase
        .from('shop_staff')
        .select('id, shop_id, full_name, role, is_active')
        .eq('user_id', userId)
        .eq('is_active', true)
        .maybeSingle();

    if (row == null) return null;

    return StaffUser(
      id: row['id'] as String,
      shopId: row['shop_id'] as String,
      fullName: row['full_name'] as String,
      email: supabase.auth.currentUser?.email ?? '',
      role: staffRoleFromString(row['role'] as String),
    );
  }
}
