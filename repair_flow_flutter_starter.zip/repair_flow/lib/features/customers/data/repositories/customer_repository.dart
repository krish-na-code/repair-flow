import '../../../../core/errors/failures.dart';
import '../../../../core/network/supabase_client_provider.dart';
import '../../../../core/utils/result.dart';
import '../../domain/entities/customer.dart';

/// All queries are automatically scoped to the caller's shop by Postgres
/// Row Level Security (see `is_shop_staff()` policy in the schema) —
/// there is no need to manually filter by shop_id on reads.
class CustomerRepository {
  Future<Result<List<Customer>>> search(String query) async {
    try {
      final rows = await supabase
          .from('customers')
          .select()
          .or('full_name.ilike.%$query%,mobile.ilike.%$query%')
          .isFilter('deleted_at', null)
          .order('created_at', ascending: false)
          .limit(50);

      return Result.ok(rows.map((row) => Customer.fromMap(row)).toList());
    } catch (e) {
      return Result.err(ServerFailure(e.toString()));
    }
  }

  Future<Result<List<Customer>>> getAll() async {
    try {
      final rows = await supabase
          .from('customers')
          .select()
          .isFilter('deleted_at', null)
          .order('created_at', ascending: false);

      return Result.ok(rows.map((row) => Customer.fromMap(row)).toList());
    } catch (e) {
      return Result.err(ServerFailure(e.toString()));
    }
  }

  Future<Result<Customer>> create(Customer customer) async {
    try {
      final row = await supabase
          .from('customers')
          .insert(customer.toInsertMap())
          .select()
          .single();

      return Result.ok(Customer.fromMap(row));
    } catch (e) {
      return Result.err(ServerFailure(e.toString()));
    }
  }

  Future<Result<List<Map<String, dynamic>>>> getRepairHistory(String customerId) async {
    try {
      final rows = await supabase
          .from('repair_jobs')
          .select('id, job_number, brand, model, stage, received_at, delivered_at')
          .eq('customer_id', customerId)
          .order('received_at', ascending: false);

      return Result.ok(List<Map<String, dynamic>>.from(rows));
    } catch (e) {
      return Result.err(ServerFailure(e.toString()));
    }
  }
}
