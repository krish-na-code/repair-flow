class Customer {
  final String id;
  final String shopId;
  final String fullName;
  final String mobile;
  final String? altMobile;
  final String? email;
  final String? address;
  final String? city;
  final String? state;
  final String? pincode;
  final String? notes;
  final DateTime createdAt;

  const Customer({
    required this.id,
    required this.shopId,
    required this.fullName,
    required this.mobile,
    this.altMobile,
    this.email,
    this.address,
    this.city,
    this.state,
    this.pincode,
    this.notes,
    required this.createdAt,
  });

  factory Customer.fromMap(Map<String, dynamic> map) {
    return Customer(
      id: map['id'] as String,
      shopId: map['shop_id'] as String,
      fullName: map['full_name'] as String,
      mobile: map['mobile'] as String,
      altMobile: map['alt_mobile'] as String?,
      email: map['email'] as String?,
      address: map['address'] as String?,
      city: map['city'] as String?,
      state: map['state'] as String?,
      pincode: map['pincode'] as String?,
      notes: map['notes'] as String?,
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }

  Map<String, dynamic> toInsertMap() {
    return {
      'shop_id': shopId,
      'full_name': fullName,
      'mobile': mobile,
      'alt_mobile': altMobile,
      'email': email,
      'address': address,
      'city': city,
      'state': state,
      'pincode': pincode,
      'notes': notes,
    };
  }
}
