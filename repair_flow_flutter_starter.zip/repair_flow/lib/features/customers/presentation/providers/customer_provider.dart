import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/repositories/customer_repository.dart';
import '../../domain/entities/customer.dart';

final customerRepositoryProvider = Provider((ref) => CustomerRepository());

final customerSearchQueryProvider = StateProvider<String>((ref) => '');

/// Re-fetches whenever the search query changes. Empty query returns
/// the most recently added customers (see repository.getAll()).
final customerListProvider = FutureProvider.autoDispose<List<Customer>>((ref) async {
  final query = ref.watch(customerSearchQueryProvider);
  final repository = ref.watch(customerRepositoryProvider);

  final result = query.trim().isEmpty
      ? await repository.getAll()
      : await repository.search(query.trim());

  return result.when(
    ok: (customers) => customers,
    err: (failure) => throw Exception(failure.message),
  );
});
