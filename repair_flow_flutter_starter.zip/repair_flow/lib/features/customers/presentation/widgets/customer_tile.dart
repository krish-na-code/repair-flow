import 'package:flutter/material.dart';

import '../../domain/entities/customer.dart';

class CustomerTile extends StatelessWidget {
  final Customer customer;

  const CustomerTile({super.key, required this.customer});

  @override
  Widget build(BuildContext context) {
    final initials = customer.fullName.trim().isEmpty
        ? '?'
        : customer.fullName.trim().split(RegExp(r'\s+')).take(2).map((w) => w[0]).join();

    return ListTile(
      leading: CircleAvatar(child: Text(initials.toUpperCase())),
      title: Text(customer.fullName),
      subtitle: Text(customer.mobile),
      trailing: const Icon(Icons.chevron_right),
      onTap: () {
        // Navigate to customer detail screen (repair history, notes) — Phase 1 follow-up.
      },
    );
  }
}
