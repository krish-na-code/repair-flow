# RepairFlow — Flutter starter

Working starter code for the Mobile Repair Shop Management System.
Wired to Supabase for Auth, Customers, and Repair Jobs (with realtime sync
and stage-update notifications). Billing, inventory, warranty, and the
public QR tracking page are stubbed as the next modules to build using the
same pattern — see `mobile-repair-shop-management-system.md` for the full
database schema, API contracts, and remaining screen specs.

## What's included and working

- **Auth** — email/password sign-in, resolves the staff member's role and
  shop from `shop_staff`, redirects between `/login` and the app based on
  session state (`features/auth/`)
- **Customers** — search, list, create (`features/customers/`)
- **Repair jobs** — filterable list, realtime updates via Supabase
  Postgres Changes, stage updates through the `update_job_stage` RPC which
  also logs history and queues customer notifications server-side
  (`features/repair_jobs/`)
- Clean architecture layering (`data` / `domain` / `presentation`) per
  feature, Riverpod for state, go_router with auth guard

## Setup

1. **Create the Supabase project and run the schema**
   Paste the SQL from Section 2 of `mobile-repair-shop-management-system.md`
   (tables, RLS policies, and the trigger) into the Supabase SQL editor,
   then the RPC functions from Section 5 (`create_repair_job`,
   `update_job_stage`, `get_job_by_qr`).

2. **Create a shop and a staff login**
   ```sql
   insert into shops (name, job_prefix) values ('My Repair Shop', 'JOB') returning id;
   -- create a user via Supabase Auth (dashboard -> Authentication -> Add user)
   -- then link it:
   insert into shop_staff (shop_id, user_id, role, full_name)
   values ('<shop_id>', '<auth_user_id>', 'admin', 'Your Name');
   ```

3. **Configure environment**
   ```bash
   cp .env.example .env
   # fill in SUPABASE_URL and SUPABASE_ANON_KEY from
   # Project Settings -> API in the Supabase dashboard
   ```

4. **Install and run**
   ```bash
   flutter pub get
   flutter run                 # mobile/desktop
   flutter run -d chrome       # web
   ```

## Next modules to build (same pattern as `repair_jobs/`)

- `device_intake/` — multi-step wizard calling `create_repair_job` RPC,
  photo upload to the `device-photos` Storage bucket, signature capture
- `qr_tracking/` — public route (no auth) calling the `get_job_by_qr` RPC,
  deployed as a Flutter Web build at `/track/:token`
- `billing/` — invoice builder calling `invoice_line_items` + the
  `generate-invoice-pdf` Edge Function
- `inventory/`, `warranty/`, `reports/`

Each should follow the existing `data/domain/presentation` split so a new
developer can find and extend any module the same way.
